package com.javaex.practice01;

import java.util.Scanner;

public class Problem006 {

  public static void main(String[] args) {
    
    Scanner sc = new Scanner(System.in);
    System.out.println("숫자를 입력하세요");
    int num = sc.nextInt(); // 임의의 숫자 입력 대기
    int i;                  // for 문의 초기값 변수
    int startNum;           // for 문의 초기값 변수에 전달할 값(1,2)
    int sum =0 ;            // 누적 값 변수
    
    //코드작성
    // 1. 짝수 인지 홀수 인지 판단
    // 2. 짝수 인지 홀수 인지에 따른 For Loop (2씩 증가후 누적)
    
    //1.
    if(num%2==0) {
      startNum = 2;
    }else {
      startNum = 1;
    }
    
    //2.
    for(i=startNum; i<=num; i+=2) {   // i = i + 2
      sum += i; //sum = sum + i;
    }
    
    System.out.println("결과값: " + sum);
    sc.close();
    
  }

}
