package com.javaex.ch5;

import java.io.File;
import java.io.FileReader;

public class InputStreamEx {

  public static void main(String[] args) {
    try {
    
      //파일 객체 생성
      File file = new File("/Users/jeongjonguk/eclipse-workspace/javaEx/src/com/javaex/ch5/Output.txt");
      
      //입력 스트림 생성
      FileReader file_reader = new FileReader(file);
      
      int cur = 0;
      while((cur = file_reader.read()) != -1){
        System.out.print((char)cur);
      }
      file_reader.close();
    } catch (Exception e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
  }

}
