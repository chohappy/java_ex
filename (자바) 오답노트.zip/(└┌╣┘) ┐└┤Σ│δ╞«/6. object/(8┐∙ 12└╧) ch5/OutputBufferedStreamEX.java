package com.javaex.ch5;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class OutputBufferedStreamEX {

  public static void main(String[] args) throws IOException {
    BufferedOutputStream bs = null;
    try {
      bs = new BufferedOutputStream(new FileOutputStream("/Users/jeongjonguk/eclipse-workspace/javaEx/src/com/javaex/ch5/Output2.txt"));
      String str ="어제는 날씨가 좋았어요";
      bs.write(str.getBytes()); //Byte형으로만 넣을 수 있음

    } catch (Exception e) {
      e.getStackTrace();
    }finally {
      bs.close();
    } 

  }

}
