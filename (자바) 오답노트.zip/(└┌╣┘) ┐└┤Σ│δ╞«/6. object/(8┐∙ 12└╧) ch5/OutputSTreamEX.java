package com.javaex.ch5;

import java.io.FileOutputStream;
import java.io.OutputStream;

public class OutputSTreamEX {

  public static void main(String[] args) {
    try {
      OutputStream out = new FileOutputStream(
          "/Users/jeongjonguk/eclipse-workspace/javaEx/src/com/javaex/ch5/Output.txt");
      
      String str = "내일도 날씨가 좋았으면 좋겠네요";
      byte[] by = str.getBytes();

      out.write(by);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

}
