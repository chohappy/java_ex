package com.javaex.practice05.problem04;

public class Rectangle extends Shape implements Resizeable{
  private double width;
  private double height;
  
  /**
   * @param w(width)
   * @param h(height)
   */
  public Rectangle(double w, double h) {
    this.width = w;
    this.height = h;
  }

  @Override
  public void resize(double s) {
    this.width = this.width * s;
    this.height = this.height * s;
  }

  @Override
  public double getArea() {
    return this.width * this.height;
  }

  @Override
  public double getPerimeter() {
    return (this.width + this.height) * 2 ;
  }

}
