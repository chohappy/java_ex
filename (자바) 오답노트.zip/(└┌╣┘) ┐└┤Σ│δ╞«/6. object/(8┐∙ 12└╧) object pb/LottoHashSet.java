package com.javaex.ch4;

import java.util.HashSet;
import java.util.Set;

public class LottoHashSet {

  public static void main(String[] args) {
    //Integer lottoNum = (int)(Math.random() * 45) + 1;
    
    Set <Integer> lotto = new HashSet<>();
    
    for(;lotto.size() < 6;) {
      lotto.add( (int)(Math.random() * 45) + 1 );
    }
    
    System.out.println(lotto);
    
    

  }

}
