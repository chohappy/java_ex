package com.javaex.practice05.problem04;

public abstract class Shape {
  private int countSides;

  /**
   * @return the countSides
   */
  public int getCountSides() {
    return countSides;
  }

  /**
   * @param countSides
   */
  public Shape(int countSides) {
    this.countSides = countSides;
  }
  
  /**
   * 
   */
  public Shape() {
  }

  abstract public double getArea();
  abstract public double getPerimeter();
}
