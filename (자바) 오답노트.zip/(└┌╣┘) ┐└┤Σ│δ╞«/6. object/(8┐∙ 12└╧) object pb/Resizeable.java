package com.javaex.practice05.problem04;

public interface Resizeable {
  public void resize(double s);
}
