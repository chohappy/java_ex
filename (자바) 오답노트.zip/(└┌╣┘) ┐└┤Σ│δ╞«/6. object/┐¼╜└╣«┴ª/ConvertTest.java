package com.javaex.practice05.problem01;

public class ConvertTest {

  public static void main(String[] args) {
    String s = "5 + 3";
    String[] sArray = s.split(" ");
    
    System.out.println(sArray[0]);
    System.out.println(sArray[1]);
    System.out.println(sArray[2]);
    
    System.out.println(sArray[0] + sArray[2]);
    
    int a = Integer.parseInt(sArray[0]);
    int b = Integer.parseInt(sArray[2]);
    
    System.out.println(a + b);
    
    System.out.println(Integer.parseInt(sArray[0]) + Integer.parseInt(sArray[2]) );
  }

}
