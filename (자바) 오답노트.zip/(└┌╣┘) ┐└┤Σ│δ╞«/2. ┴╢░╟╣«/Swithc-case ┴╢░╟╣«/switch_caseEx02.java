package com.javaex.helloworld;

import java.util.Scanner;

public class switch_caseEx02 {
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    System.out.println("월을 입력하세요");
    
    int month = sc.nextInt();
    
    /*
    1월이면 “31일”
    2월이면 “28일”
    3월이면 “31일”
    4월이면 “30일”
    5월이면 “31일”
    6월이면 “30일”
    7월이면 “31일”
    8월이면 “31일”
    9월이면 “30일”
    10월이면 “31일”
    11월이면 “30일”
    12월이면 “31일”
    */
    
    
    switch(month) {
    case 1:
    case 3:
    case 5:
    case 7:
    case 8:
    case 10:
    case 12:
      System.out.println("31일 입니다.");
      break;
      
    case 2:
      System.out.println("28일 입니다.");
      break;
      
    case 4:
    case 6:
    case 9:
    case 11:
      System.out.println("30일 입니다.");
      break;
    }
    
    
    sc.close();
  }
}
