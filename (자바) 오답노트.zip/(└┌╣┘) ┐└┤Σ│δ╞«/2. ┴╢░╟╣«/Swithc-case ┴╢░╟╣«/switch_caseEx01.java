package com.javaex.helloworld;

import java.util.Scanner;

public class switch_caseEx01 {
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    System.out.println("과목을 선택하세요");
    System.out.println("(1.JAVA  2.C  3.C++  4.Pyhthon)");
    System.out.print("과목번호:");
    
    int code = sc.nextInt();
    
    /*
    1이면 “R101호 입니다.”
    2이면 “R202호 입니다.”
    3이면 “R303호 입니다.”
    4이면 “R404호 입니다.”
    나머지는 “상담원에게 문의하세요”
    */
    
//    if(code == 1) {
//      System.out.println("R101호 입니다.");
//    }else if(code == 2) {
//      System.out.println("R202호 입니다.");
//    }else if(code == 3) {
//      System.out.println("R303호 입니다.");
//    }else if(code == 4) {
//      System.out.println("R404호 입니다.");
//    }else {
//      System.out.println("상담원에게 문의하세요");
//    }
    
    switch(code) {
    case 1:
      System.out.println("R101호 입니다.");
      break;
    case 2:
      System.out.println("R202호 입니다.");
      break;
    case 3:
      System.out.println("R303호 입니다.");
      break;
    case 4:
      System.out.println("R404호 입니다.");
      break;
    default :
      System.out.println("상담원에게 문의하세요");
      break;
    }
    
    
    sc.close();
  }
}
