package com.javaex.practice.problem03;

public class Print {
    
    public void printer(int val){
        System.out.println(val);
    }

		public void printer(boolean b) {
				System.out.println(b);
		}

		public void printer(double d) {
			System.out.println(d);
		}

		public void printer(String string) {
			System.out.println(string);
		}

}
