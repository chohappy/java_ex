package com.javaex.practice.problem07;
public class Account {
	private String accountNo; // 계좌번호
  private int balance;      // 잔액
	
  //필요한 메소드 작성
  public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	
	//생성자 작성
	public Account() {
		super();
	}
	public Account(String accountNo, int balance) {
		super();
		this.accountNo = accountNo;
		this.balance = balance;
		System.out.println(accountNo + " 계좌가 개설되었습니다");
	}
	public Account(String accountNo) {
		this(accountNo, 0);
	}
	public void deposit(int money) {
	  this.balance += money;
	}
	public void withdraw(int money) {
		//this.balance -= money;
		if(this.balance < money) {
			System.out.println("잔고액이 부족합니다");
		}else {
			this.balance -= money;
		}
	}
	public void showBalance() {
		System.out.println(this.balance);
	}
  
  
  
  
}
