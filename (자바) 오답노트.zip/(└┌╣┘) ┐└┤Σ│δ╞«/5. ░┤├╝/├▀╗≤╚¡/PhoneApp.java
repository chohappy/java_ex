package com.oop.abs;

public class PhoneApp {

  public static void main(String[] args) {
    Telephone t = new Telephone("02-1234-5678");
    t.power(true);
    t.call("010-1234-5678");
    
    Smartphone sp = new Smartphone("010-1234-1234", false);
    sp.turnOn(true);
    sp.call("119");
    sp.searchInternet("www.naver.com");

  }

}
