package com.javaex.ch2;

public class GoodsApp {

  public static void main(String[] args) {
    Goods camera = new Goods();
    
    // 이름 : nikon
    // 가격 : 400000
    camera.setName("nikon");
    camera.setPrice(400000);
    
    System.out.println("제품이름 : " + camera.getName());
    System.out.println("제품가격 : " + camera.getPrice());
    
    // 이름 : LG그램
    // 가격 : 900000
    Goods notebook = new Goods();
    notebook.setName("LG그램");
    notebook.setPrice(900000);
    
    System.out.println("제품이름 : " + notebook.getName());
    System.out.println("제품가격 : " + notebook.getPrice());
    
    // 이름 : 머그컵
    // 가격 : 2000
    Goods cup = new Goods("머그컵",2000);
    
    System.out.println("제품이름 : " + cup.getName());
    System.out.println("제품가격 : " + cup.getPrice());
  }

}
