package com.javaex.ch2;

public class SongApp {

  public static void main(String[] args) {
    //Song(String title, String artist, String album, String composer, int year, int track) {
    Song s1 = new Song("좋은날", "아이유", "Real", "이민수", 2010, 3);
    s1.showInfo();

  }

}
