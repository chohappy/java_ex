package com.javaex.ch2;

public class ColorPoint extends Point {
  private String color;

  public String getColor() {
    return color;
  }

  public void setColor(String color) {
    this.color = color;
  }

  public ColorPoint(int x, int y) {
    super(x, y);
  }

  public ColorPoint(int x, int y, String color) {
    super(x, y);
    this.color = color;
  }

  @Override
  public String toString() {
    return "ColorPoint [color=" + color + "]";
  }
  
  public void showInfo() {
    System.out.print("Point [x=" + super.getX() + ", y=" + super.getY() + ", ");
    System.out.println( "color=" + color + "]");
  }

  public ColorPoint(String color) {
    this.color = color;
  }
}
