package com.javaex.ch2;

public class TVApp {

  public static void main(String[] args) {
    TV tv = new TV();
    
    tv.status();
    
    tv.power(true);
    tv.volume(120);
    tv.status();
    
    tv.volume(false);
    tv.status();
    
    tv.channel(0); // 없는 채널을 선택하면 보고있던 채널을 다시 표시
    tv.status();
    
    tv.channel(true);
    tv.channel(true);
    tv.channel(true);
    tv.status();
    
    tv.power(false);
    tv.status();

  }

}
