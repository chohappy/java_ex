package com.javaex.practice.problem02;

public class EmployeeApp {

    public static void main(String[] args) {

        Employee pt = new Depart( "홍길동", 5000, "개발부" );
        pt.getInformation();
    }

}