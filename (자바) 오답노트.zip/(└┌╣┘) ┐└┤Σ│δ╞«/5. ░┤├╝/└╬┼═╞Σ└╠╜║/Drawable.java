package com.javaex.oop;

public interface Drawable {
  public void draw();
}
