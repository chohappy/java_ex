package com.javaex.oop;

public class ShapeApp {

  public static void main(String[] args) {
    Rectangle r = new Rectangle();
    r.setWidth(3.3);
    r.setHeight(123.4);
    System.out.println( "사각형의 넓이는 : " + r.area() );
    
    Triangle t = new Triangle(3.0,4.0);
    System.out.println( "삼각형의 넓이는 : " + t.area() );
    
    Circle c = new Circle(5.0);
    System.out.println( "원의 넓이는 : " + c.area() );
    
    Shape c1 = new Circle(3.0);
    
    // c1 객체가 Circle 클래스의 인스턴스 인가?
    System.out.println( c1 instanceof Circle );
    
    // c1 객체가 Drawable 인터페이스를 구현하였는가?
    System.out.println( c1 instanceof Drawable );
    
    // 객체가 Rectangle 클래스의 인스턴스 인가?
    System.out.println( c1 instanceof Rectangle );
    
    // 객체가 Shape 클래스의 인스턴스 인가?
    System.out.println( c1 instanceof Shape ); 






  }

}
