package com.javaex.oop;

public class Rectangle extends Shape {
  private double width;
  private double height;

  public Rectangle(int width, int height) {
    this.width = width;
    this.height = height;
  }

  public Rectangle() {
    // TODO Auto-generated constructor stub
  }

  public void setWidth(double width) {
    this.width = width;
  }

  public void setHeight(double height) {
    this.height = height;
  }

  @Override
  public double area() {
    // 사각형의 넓이 리턴
    return this.width * this.height;
  }

  // equal메소드 재정의
  public boolean equals(Object obj) {
    Rectangle r = ((Rectangle) obj);
    if (this.hashCode() == r.hashCode()) {
      return true;
    } else if (this.area() == r.area()) {
      return true;
    } else {
      return false;
    }
  }

}
