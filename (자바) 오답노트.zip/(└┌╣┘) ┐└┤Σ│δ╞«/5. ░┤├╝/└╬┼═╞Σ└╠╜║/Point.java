package com.javaex.oop;

public class Point {
  private int x;
  private int y;
  public int getX() {
    return x;
  }
  public void setX(int x) {
    this.x = x;
  }
  public int getY() {
    return y;
  }
  public void setY(int y) {
    this.y = y;
  }

  public void draw() {
    System.out.println("점[x="+getX()+", y="+ this.y +"]을 그렸습니다.");
  }
  
  public void draw(boolean deleteYN) {
    if(deleteYN) {
      System.out.println("점[x="+getX()+", y="+ this.y +"]을 지웠습니다.");
      this.setX(0);
      this.setY(0);
      
    }
    
  }
  
  /**
   * @param x
   * @param y
   */
  public Point(int x, int y) {
    super();
    this.x = x;
    this.y = y;
  }
  /**
   * 
   */
  public Point() {
    super();
  }
  
  //equal메소드 재정의
  public boolean equals(Object obj) {
     Point p = ((Point)obj);
     if(this.hashCode() == p.hashCode()){
         return true;
     }else if( this.x == p.x && this.y == p.y) {
         return true;
     } else {
         return false;  
     }
  }

  
  
}
