package com.javaex.oop;

public class Circle extends Shape implements Drawable{
  private double radius;
  
  public void setRadius(double radius) {
    this.radius = radius;
  }

  @Override
  public double area() {
    // 원의 넓이 리턴
    return this.radius * this.radius * 3.14;
  }

  /**
   * @param radius
   */
  public Circle(double radius) {
    super();
    this.radius = radius;
  }

  @Override
  public void draw() {
    System.out.println("반지름이 "+this.radius+"인 원을 그렸습니다.");
  }
  
}
