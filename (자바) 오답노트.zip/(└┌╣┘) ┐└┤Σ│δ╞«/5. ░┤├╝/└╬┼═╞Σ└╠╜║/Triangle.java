package com.javaex.oop;

public class Triangle extends Shape{
  
  private double width;
  private double height;
  
  public void setWidth(double width) {
    this.width = width;
  }

  public void setHeight(double height) {
    this.height = height;
  }

  @Override
  public double area() {
    // 삼각형의 넓이 리터
    return (this.width * this.height) / 2.0;
  }

  /**
   * @param width
   * @param height
   */
  public Triangle(double width, double height) {
    super();
    this.width = width;
    this.height = height;
  }
  
}
