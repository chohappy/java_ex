package com.javaex.practice;

import java.util.Scanner;

public class Problem06 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("숫자를 입력하세요");
		int num = sc.nextInt();
		int i;
		int startNum;
		int sum =0 ;
		
		//코드작성
		
		System.out.println("결과값: " + sum);
		sc.close();
	}
}
