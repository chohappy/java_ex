package com.javaex.problem03;

public class Print {
    
    public void printer(int val){
        System.out.println(val);
    }

    //메소드  작성
    
}
