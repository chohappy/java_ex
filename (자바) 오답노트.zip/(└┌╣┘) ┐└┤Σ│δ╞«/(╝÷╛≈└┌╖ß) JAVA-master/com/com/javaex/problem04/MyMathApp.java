package com.javaex.problem04;


public class MyMathApp {

    public static void main(String[] args) {

        //원의 넓이 계산
        
        
    }

}
