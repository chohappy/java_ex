package com.javaex.helloworld;

import java.util.Scanner;

public class DoWhileEx01 {

  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    int sum = 0;
    int input;
    //boolean run = false;
    
    System.out.println("숫자를 입력하세요[0 종료]");
    
    do {
      //run = true;
      input = sc.nextInt();
      
      if(input==0) {
        //종료
        //run = false;
        break;
      }
      
      sum = sum + input; // 누적
      
      System.out.println("합계 : " + sum);
    }while(true);
    
  }

}
